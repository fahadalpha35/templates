# Login , Signup and forgat password page with tailwind css

A Pen created on CodePen.io. Original URL: [https://codepen.io/Kuldeep-Sikarwar/pen/QWXrrxj](https://codepen.io/Kuldeep-Sikarwar/pen/QWXrrxj).

Login , Signup and forgot password page in one file  with also use  tailwind css 