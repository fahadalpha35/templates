# Basic sample signup form (Accessability friendly)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lmonk72/pen/vYbbKJL](https://codepen.io/Lmonk72/pen/vYbbKJL).

A simple signup form with an accessible and semantically structured  HTML markup. CSS is designed to work in light and dark mode.